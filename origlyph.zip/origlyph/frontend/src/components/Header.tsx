import React from 'react';
import { Compass, BookOpen, Share2, HelpCircle, Trophy } from 'lucide-react';

interface HeaderProps {
  currentView: 'game' | 'catalog' | 'global-graph';
  onNavigate: (view: 'game' | 'catalog' | 'global-graph') => void;
  onOpenIntegrationGuide: () => void;
  totalScore: number;
  completedCount: number;
  playableCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onOpenIntegrationGuide,
  totalScore,
  completedCount,
  playableCount,
}) => {
  return (
    <header className="site-header">
      <div className="brand-section">
        <div className="brand-logo font-serif">O</div>
        <div>
          <a
            href="#"
            className="brand-title font-serif"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('game');
            }}
          >
            Origlyph
          </a>
          <div className="brand-tagline">Decode the places behind culture</div>
        </div>
      </div>

      <nav className="header-nav" aria-label="Main Navigation">
        <button
          className={`nav-link-btn ${currentView === 'game' ? 'active' : ''}`}
          onClick={() => onNavigate('game')}
        >
          <Compass size={16} />
          Challenge
        </button>

        <button
          className={`nav-link-btn ${currentView === 'catalog' ? 'active' : ''}`}
          onClick={() => onNavigate('catalog')}
        >
          <BookOpen size={16} />
          Archive Catalog
        </button>

        <button
          className={`nav-link-btn ${currentView === 'global-graph' ? 'active' : ''}`}
          onClick={() => onNavigate('global-graph')}
        >
          <Share2 size={16} />
          Provenance Graph
        </button>

        <button
          className="nav-link-btn"
          onClick={onOpenIntegrationGuide}
          title="Architecture & Partner Integration Guide"
        >
          <HelpCircle size={16} />
          Integrations
        </button>

        <div className="stat-pill" title="Total Session Score">
          <Trophy size={13} style={{ display: 'inline', marginRight: '4px', verticalAlign: '-1px' }} />
          {totalScore.toLocaleString()} PTS ({completedCount}/{playableCount})
        </div>
      </nav>
    </header>
  );
};
