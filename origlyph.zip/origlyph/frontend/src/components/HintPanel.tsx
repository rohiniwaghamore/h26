import React from 'react';
import { Lightbulb, AlertTriangle, CheckCircle2, ChevronRight } from 'lucide-react';
import { HintResponse } from '../types';

interface HintPanelProps {
  unlockedHints: HintResponse[];
  onUnlockHint: (level: number) => void;
  isLoading: boolean;
  disabled: boolean;
}

export const HintPanel: React.FC<HintPanelProps> = ({
  unlockedHints,
  onUnlockHint,
  isLoading,
  disabled,
}) => {
  const currentLevel = unlockedHints.length;

  return (
    <section className="hint-section" aria-label="Progressive Hints">
      <div className="hint-header">
        <div className="hint-title font-serif">
          <Lightbulb size={17} color="var(--accent-gold)" />
          Evidence-Backed Clues
        </div>
        <div className="stat-pill" style={{ color: 'var(--accent-gold)' }}>
          {currentLevel}/3 Unlocked
        </div>
      </div>

      <div className="hint-tier-buttons">
        <button
          className={`hint-btn ${currentLevel >= 1 ? 'unlocked' : ''}`}
          onClick={() => onUnlockHint(1)}
          disabled={disabled || isLoading || currentLevel >= 1}
        >
          {currentLevel >= 1 ? <CheckCircle2 size={13} /> : <ChevronRight size={13} />}
          Tier 1: Era & Context
          <span className="hint-penalty-tag">(-500 pts)</span>
        </button>

        <button
          className={`hint-btn ${currentLevel >= 2 ? 'unlocked' : ''}`}
          onClick={() => onUnlockHint(2)}
          disabled={disabled || isLoading || currentLevel !== 1}
        >
          {currentLevel >= 2 ? <CheckCircle2 size={13} /> : <ChevronRight size={13} />}
          Tier 2: Topography
          <span className="hint-penalty-tag">(-1,200 pts)</span>
        </button>

        <button
          className={`hint-btn ${currentLevel >= 3 ? 'unlocked' : ''}`}
          onClick={() => onUnlockHint(3)}
          disabled={disabled || isLoading || currentLevel !== 2}
        >
          {currentLevel >= 3 ? <CheckCircle2 size={13} /> : <ChevronRight size={13} />}
          Tier 3: Archival Record
          <span className="hint-penalty-tag">(-2,200 pts)</span>
        </button>
      </div>

      {unlockedHints.length > 0 ? (
        <div className="hints-stream">
          {unlockedHints.map((hint) => (
            <div key={hint.hint_level} className="hint-card">
              <div className="hint-card-meta">
                <span>Tier {hint.hint_level} Archival Extraction</span>
                <span>Penalty: -{hint.score_penalty.toLocaleString()} PTS</span>
              </div>
              <p>{hint.hint_text}</p>
              {hint.caveat_or_uncertainty && (
                <div className="hint-card-caveat">
                  <AlertTriangle size={12} style={{ display: 'inline', marginRight: '4px', verticalAlign: '-1px' }} />
                  {hint.caveat_or_uncertainty}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div style={{ marginTop: '0.75rem', fontSize: '0.8rem', color: 'var(--text-faint)' }}>
          Request progressive evidence-backed hints if you need historical context or geographical clues. Each hint carries a transparent score penalty.
        </div>
      )}
    </section>
  );
};
