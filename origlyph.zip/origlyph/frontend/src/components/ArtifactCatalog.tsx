import React, { useState } from 'react';
import { Compass, ShieldCheck, AlertCircle, Eye, ExternalLink } from 'lucide-react';
import { ArtifactChallengeView } from '../types';
import { formatLocationBasis, getArtworkFallbackSvg } from '../utils/formatters';

interface ArtifactCatalogProps {
  artifacts: ArtifactChallengeView[];
  activeArtifactId: string;
  onSelectArtifact: (id: string) => void;
}

export const ArtifactCatalog: React.FC<ArtifactCatalogProps> = ({
  artifacts,
  activeArtifactId,
  onSelectArtifact,
}) => {
  const [filter, setFilter] = useState<'all' | 'playable' | 'fixtures'>('all');

  const filtered = artifacts.filter((a) => {
    if (filter === 'playable') return a.is_playable;
    if (filter === 'fixtures') return !a.is_playable;
    return true;
  });

  return (
    <div style={{ padding: '2rem 1rem' }}>
      <div style={{ maxWidth: '1400px', margin: '0 auto 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '1rem', padding: '0 1rem' }}>
        <div>
          <h2 className="font-serif" style={{ fontSize: '1.75rem' }}>
            Archival Cultural Heritage Catalog
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: '0.2rem' }}>
            Curated seed records spanning historical prints, monumental epigraphy, ancient sculpture, and archaeological sanctuaries.
          </p>
        </div>

        {/* Filter buttons */}
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button
            className={`nav-link-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            All Archives ({artifacts.length})
          </button>
          <button
            className={`nav-link-btn ${filter === 'playable' ? 'active' : ''}`}
            onClick={() => setFilter('playable')}
          >
            Playable Challenges ({artifacts.filter((a) => a.is_playable).length})
          </button>
          <button
            className={`nav-link-btn ${filter === 'fixtures' ? 'active' : ''}`}
            onClick={() => setFilter('fixtures')}
          >
            Fixtures & Unverified ({artifacts.filter((a) => !a.is_playable).length})
          </button>
        </div>
      </div>

      <div className="catalog-grid">
        {filtered.map((artifact) => {
          const isActive = artifact.id === activeArtifactId;
          const fallbackImg = getArtworkFallbackSvg(artifact.id, artifact.title);

          return (
            <div
              key={artifact.id}
              className="catalog-card"
              style={{
                border: isActive ? '2px solid var(--accent-sage)' : undefined,
                opacity: !artifact.is_playable ? 0.75 : 1,
              }}
              onClick={() => {
                if (artifact.is_playable) {
                  onSelectArtifact(artifact.id);
                }
              }}
            >
              <img
                src={artifact.media_url || fallbackImg}
                alt={artifact.title}
                className="catalog-card-thumb"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = fallbackImg;
                }}
              />

              <div className="catalog-card-body">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className="stat-pill" style={{ fontSize: '0.7rem' }}>
                    {artifact.source_name}
                  </span>
                  {artifact.is_playable ? (
                    <span style={{ fontSize: '0.72rem', color: 'var(--accent-sage-bright)', display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
                      <ShieldCheck size={12} /> Verified
                    </span>
                  ) : (
                    <span style={{ fontSize: '0.72rem', color: 'var(--accent-rust)', display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
                      <AlertCircle size={12} /> Fixture
                    </span>
                  )}
                </div>

                <h3 className="catalog-card-title font-serif">{artifact.title}</h3>

                {artifact.creator && (
                  <div className="catalog-card-meta">
                    {artifact.creator} {artifact.date_created ? `(${artifact.date_created})` : ''}
                  </div>
                )}

                <div style={{ fontSize: '0.78rem', color: 'var(--text-faint)' }}>
                  Location Basis: {formatLocationBasis(artifact.location_basis)}
                </div>

                <div className="catalog-card-footer">
                  <span>{artifact.verified_fact_count} Verified Facts</span>
                  {artifact.is_playable ? (
                    <button
                      className="nav-link-btn active"
                      style={{ padding: '0.3rem 0.6rem', fontSize: '0.75rem' }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectArtifact(artifact.id);
                      }}
                    >
                      <Compass size={12} /> Play
                    </button>
                  ) : (
                    <span style={{ fontSize: '0.72rem', fontStyle: 'italic' }}>Excluded from scoring</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
