import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { MapPin, Navigation, CheckCircle } from 'lucide-react';
import { GuessResponse } from '../types';

interface MapGuessProps {
  userGuess: { lat: number; lng: number } | null;
  onSelectCoordinates: (coords: { lat: number; lng: number }) => void;
  onSubmitGuess: () => void;
  revealData: GuessResponse | null;
  isSubmitting: boolean;
  disabled: boolean;
}

export const MapGuess: React.FC<MapGuessProps> = ({
  userGuess,
  onSelectCoordinates,
  onSubmitGuess,
  revealData,
  isSubmitting,
  disabled,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const guessMarkerRef = useRef<L.Marker | null>(null);
  const targetMarkerRef = useRef<L.Marker | null>(null);
  const polylineRef = useRef<L.Polyline | null>(null);

  // Initialize Leaflet map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    // Default global view
    const map = L.map(mapContainerRef.current, {
      center: [25, 10],
      zoom: 3,
      minZoom: 2,
      maxZoom: 18,
      zoomControl: true,
      attributionControl: true,
    });

    // Dark-toned CartoDB Voyager or OpenStreetMap tiles with attribution
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions" target="_blank">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(map);

    // Click handler for pin placement
    map.on('click', (e: L.LeafletMouseEvent) => {
      if (disabled || revealData) return;
      onSelectCoordinates({ lat: e.latlng.lat, lng: e.latlng.lng });
    });

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update User Guess Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (userGuess) {
      const customIcon = L.divIcon({
        className: 'custom-map-pin',
        html: `<div style="background-color:#d8b86d; width:16px; height:16px; border-radius:50%; border:3px solid #0b1311; box-shadow:0 0 10px rgba(216,184,109,0.8);"></div>`,
        iconSize: [20, 20],
        iconAnchor: [10, 10],
      });

      if (!guessMarkerRef.current) {
        guessMarkerRef.current = L.marker([userGuess.lat, userGuess.lng], { icon: customIcon }).addTo(map);
      } else {
        guessMarkerRef.current.setLatLng([userGuess.lat, userGuess.lng]);
      }
    } else if (guessMarkerRef.current) {
      map.removeLayer(guessMarkerRef.current);
      guessMarkerRef.current = null;
    }
  }, [userGuess]);

  // Handle Post-Guess Reveal State
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (revealData) {
      // Create True Target Marker (Emerald)
      const targetIcon = L.divIcon({
        className: 'target-map-pin',
        html: `<div style="background-color:#89b399; width:20px; height:20px; border-radius:50%; border:3px solid #ffffff; box-shadow:0 0 14px rgba(137,179,153,1);"></div>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });

      if (!targetMarkerRef.current) {
        targetMarkerRef.current = L.marker(
          [revealData.target_latitude, revealData.target_longitude],
          { icon: targetIcon }
        )
          .addTo(map)
          .bindPopup(`<b>Documented Target Location</b><br/>${revealData.artifact.title}`)
          .openPopup();
      }

      // Draw geodesic line between Guess and Target
      const latlngs = [
        [revealData.guess_latitude, revealData.guess_longitude],
        [revealData.target_latitude, revealData.target_longitude],
      ];

      if (!polylineRef.current) {
        polylineRef.current = L.polyline(latlngs as any, {
          color: '#89b399',
          weight: 3,
          opacity: 0.85,
          dashArray: '6, 8',
        }).addTo(map);
      }

      // Fit map view to bounds
      const bounds = L.latLngBounds([
        [revealData.guess_latitude, revealData.guess_longitude],
        [revealData.target_latitude, revealData.target_longitude],
      ]);
      map.fitBounds(bounds, { padding: [80, 80], maxZoom: 10 });
    } else {
      // Clear reveal markers when round resets
      if (targetMarkerRef.current) {
        map.removeLayer(targetMarkerRef.current);
        targetMarkerRef.current = null;
      }
      if (polylineRef.current) {
        map.removeLayer(polylineRef.current);
        polylineRef.current = null;
      }
    }
  }, [revealData]);

  return (
    <div className="map-pane">
      <div ref={mapContainerRef} className="map-viewport" />

      {/* Coordinate & Status Overlay */}
      <div className="map-control-overlay">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-muted)' }}>
          <MapPin size={14} />
          <span>Investigation Coordinates</span>
        </div>
        <div className="coord-display">
          {userGuess
            ? `${userGuess.lat.toFixed(4)}°, ${userGuess.lng.toFixed(4)}°`
            : 'Click on the map to place a pin'}
        </div>
      </div>

      {/* Floating Action Bar */}
      {!revealData && (
        <div className="map-actions-bar">
          <button
            className="guess-submit-btn"
            onClick={onSubmitGuess}
            disabled={!userGuess || isSubmitting || disabled}
          >
            {isSubmitting ? (
              'Calculating Geodesic...'
            ) : (
              <>
                <Navigation size={17} />
                Submit Geographic Guess
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
