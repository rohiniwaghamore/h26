import React, { useState } from 'react';
import { ExternalLink, Maximize2, ShieldCheck, MapPin, Eye } from 'lucide-react';
import { ArtifactChallengeView } from '../types';
import { formatLocationBasis, getArtworkFallbackSvg } from '../utils/formatters';

interface ArtifactViewerProps {
  artifact: ArtifactChallengeView;
}

export const ArtifactViewer: React.FC<ArtifactViewerProps> = ({ artifact }) => {
  const [imgError, setImgError] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);

  const imageSrc =
    !imgError && artifact.media_url
      ? artifact.media_url
      : getArtworkFallbackSvg(artifact.id, artifact.title);

  return (
    <div className="artifact-metadata">
      {/* Visual Artifact Canvas */}
      <div className="artifact-image-container">
        <img
          src={imageSrc}
          alt={artifact.title}
          className="artifact-image"
          onError={() => setImgError(true)}
          loading="eager"
        />

        <div className="image-overlay-badge">
          <ShieldCheck size={14} />
          {artifact.source_name}
        </div>

        <button
          className="image-zoom-btn"
          onClick={() => setIsZoomed(true)}
          title="Inspect high-resolution image"
        >
          <Maximize2 size={13} />
          Inspect
        </button>
      </div>

      {/* Header and Attribution */}
      <div className="artifact-meta-header">
        <div>
          <span className="challenge-badge">
            <Eye size={12} />
            Archival Record {artifact.id}
          </span>
          <h1 className="artifact-title font-serif" style={{ marginTop: '0.4rem' }}>
            {artifact.title}
          </h1>
          {artifact.creator && (
            <div className="artifact-creator-line">
              {artifact.creator} {artifact.date_created ? `• ${artifact.date_created}` : ''}
            </div>
          )}
        </div>
      </div>

      {/* Target Basis Callout */}
      <div className="target-basis-callout">
        <MapPin size={20} color="var(--accent-sage)" style={{ marginTop: '2px', flexShrink: 0 }} />
        <div>
          <div className="target-basis-title">
            Target Objective: {formatLocationBasis(artifact.location_basis)}
          </div>
          <div className="target-basis-desc">
            Place your pin on the map where this cultural record was{' '}
            {artifact.location_basis === 'depicted'
              ? 'depicted / viewed'
              : artifact.location_basis === 'discovery'
              ? 'archaeologically discovered'
              : 'created or produced'}
            .
          </div>
        </div>
      </div>

      {/* Description */}
      <p className="artifact-desc">{artifact.description}</p>

      {/* Canonical Source Link */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
        <span>Canonical Record:</span>
        <a
          href={artifact.source_url}
          target="_blank"
          rel="noopener noreferrer"
          style={{ color: 'var(--accent-sage-bright)', display: 'inline-flex', alignItems: 'center', gap: '0.3rem', textDecoration: 'none' }}
        >
          {artifact.source_name} <ExternalLink size={12} />
        </a>
      </div>

      {/* High-Resolution Zoom Modal */}
      {isZoomed && (
        <div className="modal-backdrop" onClick={() => setIsZoomed(false)}>
          <div
            className="modal-card"
            style={{ maxWidth: '90vw', maxHeight: '90vh', background: '#050b09' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="modal-header">
              <span className="font-serif" style={{ fontSize: '1.1rem' }}>
                {artifact.title} — High Resolution Inspection
              </span>
              <button className="modal-close-btn" onClick={() => setIsZoomed(false)}>
                ✕
              </button>
            </div>
            <div style={{ padding: '1rem', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <img
                src={imageSrc}
                alt={artifact.title}
                style={{ maxWidth: '100%', maxHeight: '78vh', objectFit: 'contain' }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
