import React from 'react';
import {
  Trophy,
  Navigation,
  Share2,
  ExternalLink,
  MapPin,
  CheckCircle2,
  BookOpen,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { GuessResponse } from '../types';
import { formatDistance, formatScore } from '../utils/formatters';

interface RevealModalProps {
  reveal: GuessResponse;
  onNextChallenge: () => void;
  onOpenProvenance: () => void;
  onClose: () => void;
}

export const RevealModal: React.FC<RevealModalProps> = ({
  reveal,
  onNextChallenge,
  onOpenProvenance,
  onClose,
}) => {
  const { artifact } = reveal;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <div className="stat-pill" style={{ display: 'inline-block', marginBottom: '0.4rem' }}>
              Round Decoded
            </div>
            <h2 className="font-serif" style={{ fontSize: '1.4rem' }}>
              {artifact.title}
            </h2>
          </div>
          <button className="modal-close-btn" onClick={onClose} aria-label="Close modal">
            ✕
          </button>
        </div>

        <div className="modal-body">
          {/* Score Banner */}
          <div className="reveal-score-banner">
            <div>
              <div className="score-metric-label">Total Score</div>
              <div className="score-metric-val">{formatScore(reveal.final_score)}</div>
              <div className="score-metric-sub">/ {reveal.max_score} PTS</div>
            </div>

            <div>
              <div className="score-metric-label">Deviation Distance</div>
              <div className="score-metric-val" style={{ color: 'var(--text-main)' }}>
                {formatDistance(reveal.distance_km)}
              </div>
              <div className="score-metric-sub">{reveal.accuracy_rating}</div>
            </div>

            <div>
              <div className="score-metric-label">Score Breakdown</div>
              <div className="score-metric-val" style={{ fontSize: '1.2rem', color: 'var(--text-muted)' }}>
                {formatScore(reveal.base_score)}
              </div>
              <div className="score-metric-sub">
                {reveal.hint_penalty > 0 ? `-${reveal.hint_penalty} hint deduction` : 'Zero hint penalty'}
              </div>
            </div>
          </div>

          {/* Fourfold Location Distinction Grid */}
          <div>
            <h3 className="font-serif" style={{ fontSize: '1.05rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <MapPin size={18} color="var(--accent-sage)" />
              Fourfold Archival Location Distinction
            </h3>
            <div className="location-distinction-grid">
              <div className="distinction-card">
                <div className="distinction-tag">1. Creation / Workshop Location</div>
                <div className="distinction-val">
                  {artifact.creation_location || 'Not explicitly recorded in archives'}
                </div>
              </div>

              <div className="distinction-card">
                <div className="distinction-tag">2. Depicted Subject Location</div>
                <div className="distinction-val">
                  {artifact.depicted_location || 'Non-representational or allegorical'}
                </div>
              </div>

              <div className="distinction-card">
                <div className="distinction-tag">3. Archaeological Discovery Site</div>
                <div className="distinction-val">
                  {artifact.discovery_location || 'Continuous above-ground custody / No excavation record'}
                </div>
              </div>

              <div className="distinction-card">
                <div className="distinction-tag">4. Holding Collection</div>
                <div className="distinction-val">
                  {artifact.current_collection || artifact.source_name}
                </div>
              </div>
            </div>
          </div>

          {/* Verified Evidence and Facts */}
          <div>
            <h3 className="font-serif" style={{ fontSize: '1.05rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <ShieldCheck size={18} color="var(--accent-sage)" />
              Verified Curatorial Evidence & Citations
            </h3>
            <div className="facts-list">
              {artifact.verified_facts.map((fact) => (
                <div key={fact.id} className="fact-item">
                  <div>{fact.fact_text}</div>
                  <div className="fact-citation">Source: {fact.source_citation}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Provenance Connections summary */}
          {artifact.relations.length > 0 && (
            <div>
              <h3 className="font-serif" style={{ fontSize: '1.05rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Share2 size={18} color="var(--accent-sage)" />
                Documented Provenance Connections ({artifact.relations.length})
              </h3>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {artifact.relations.map((rel, idx) => (
                  <span
                    key={idx}
                    className="stat-pill"
                    style={{ background: 'var(--bg-primary)', display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}
                    title={rel.notes || rel.relation_type}
                  >
                    <span style={{ color: 'var(--text-muted)' }}>{rel.relation_type}:</span> {rel.target_name}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', borderTop: '1px solid var(--bg-surface-border)', paddingTop: '1.5rem' }}>
            <button
              className="nav-link-btn active"
              onClick={onOpenProvenance}
              style={{ flex: 1, justifyContent: 'center', padding: '0.8rem' }}
            >
              <Share2 size={16} />
              Explore Provenance Graph
            </button>

            <button
              className="guess-submit-btn"
              onClick={onNextChallenge}
              style={{ flex: 1, justifyContent: 'center' }}
            >
              Next Artifact Challenge
              <ArrowRight size={17} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
