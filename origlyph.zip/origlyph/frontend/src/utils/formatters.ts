export function formatDistance(km: number): string {
  if (km < 1) {
    return `${Math.round(km * 1000)} m`;
  }
  return `${km.toLocaleString(undefined, { maximumFractionDigits: 1 })} km`;
}

export function formatScore(score: number): string {
  return score.toLocaleString();
}

export function formatLocationBasis(basis?: string | null): string {
  switch (basis) {
    case 'creation':
      return 'Creation Location (Workshop/Studio)';
    case 'depicted':
      return 'Depicted Subject Location';
    case 'discovery':
      return 'Archaeological Discovery Site';
    default:
      return 'Documented Provenance Location';
  }
}

export function getScoreBadgeClass(score: number): string {
  if (score >= 4500) return 'badge-gold';
  if (score >= 3500) return 'badge-emerald';
  if (score >= 2000) return 'badge-amber';
  return 'badge-slate';
}

/**
 * Procedural cultural SVG fallback representations when external museum CDNs
 * or Wikimedia URLs fail to load.
 */
export function getArtworkFallbackSvg(id: string, title: string): string {
  if (id.includes('001') || id.includes('002')) {
    // Japanese Wave / Night motif
    return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="100%" height="100%"><rect width="800" height="600" fill="%230f1d19"/><circle cx="560" cy="220" r="140" fill="%23e8dfc8" opacity="0.85"/><path d="M420,380 L560,180 L680,380 Z" fill="%232b3d36"/><path d="M0,450 Q180,320 380,480 T800,420 L800,600 L0,600 Z" fill="%2319453b"/><path d="M0,500 Q250,380 480,520 T800,480 L800,600 L0,600 Z" fill="%23112d26"/><text x="40" y="80" fill="%23d8dfd5" font-family="serif" font-size="28" letter-spacing="2">ORIGLYPH ARCHIVE</text><text x="40" y="120" fill="%238fa395" font-family="sans-serif" font-size="16">${encodeURIComponent(title)}</text></svg>`;
  }

  if (id.includes('003') || id.includes('004')) {
    // Egyptian Antiquities / Stele motif
    return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="100%" height="100%"><rect width="800" height="600" fill="%231a1714"/><rect x="240" y="80" width="320" height="460" rx="40" fill="%232a2620" stroke="%23c4a265" stroke-width="2"/><line x1="280" y1="180" x2="520" y2="180" stroke="%23c4a265" stroke-width="2" stroke-dasharray="8,6"/><line x1="280" y1="260" x2="520" y2="260" stroke="%23c4a265" stroke-width="2" stroke-dasharray="12,4"/><line x1="280" y1="340" x2="520" y2="340" stroke="%23c4a265" stroke-width="2" stroke-dasharray="6,6"/><circle cx="400" cy="135" r="25" fill="%23c4a265" opacity="0.8"/><text x="40" y="550" fill="%23c4a265" font-family="serif" font-size="22" letter-spacing="3">ANTIQUITY ARCHIVAL RECORD</text></svg>`;
  }

  // General Classical / Cartographic motif
  return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="100%" height="100%"><rect width="800" height="600" fill="%23121715"/><circle cx="400" cy="300" r="180" fill="none" stroke="%233a4c44" stroke-width="2"/><circle cx="400" cy="300" r="120" fill="none" stroke="%233a4c44" stroke-width="1" stroke-dasharray="4,4"/><path d="M400,100 L400,500 M200,300 L600,300" stroke="%233a4c44" stroke-width="1"/><polygon points="400,240 420,300 400,290 380,300" fill="%238fa395"/><text x="400" y="360" text-anchor="middle" fill="%23d8dfd5" font-family="serif" font-size="20" letter-spacing="2">${encodeURIComponent(title)}</text></svg>`;
}
