import React, { useState, useEffect } from 'react';
import { api } from './services/api';
import {
  ArtifactChallengeView,
  GuessResponse,
  HintResponse,
  ProvenanceGraphResponse,
} from './types';
import { Header } from './components/Header';
import { ArtifactViewer } from './components/ArtifactViewer';
import { HintPanel } from './components/HintPanel';
import { MapGuess } from './components/MapGuess';
import { RevealModal } from './components/RevealModal';
import { ProvenanceGraph } from './components/ProvenanceGraph';
import { ArtifactCatalog } from './components/ArtifactCatalog';
import { IntegrationGuideModal } from './components/IntegrationGuideModal';
import { Compass, BookOpen, AlertCircle, RefreshCw } from 'lucide-react';

export const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'game' | 'catalog' | 'global-graph'>('game');
  const [artifacts, setArtifacts] = useState<ArtifactChallengeView[]>([]);
  const [activeArtifact, setActiveArtifact] = useState<ArtifactChallengeView | null>(null);

  // Round State
  const [userGuess, setUserGuess] = useState<{ lat: number; lng: number } | null>(null);
  const [unlockedHints, setUnlockedHints] = useState<HintResponse[]>([]);
  const [revealData, setRevealData] = useState<GuessResponse | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingHint, setIsLoadingHint] = useState(false);

  // Modals & Panels
  const [isRevealModalOpen, setIsRevealModalOpen] = useState(false);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);
  const [graphData, setGraphData] = useState<ProvenanceGraphResponse | null>(null);
  const [isLoadingGraph, setIsLoadingGraph] = useState(false);

  // Session Tally
  const [totalScore, setTotalScore] = useState(0);
  const [completedIds, setCompletedIds] = useState<Set<string>>(new Set());
  const [globalError, setGlobalError] = useState<string | null>(null);

  // Load initial catalog
  useEffect(() => {
    async function loadInitialData() {
      try {
        setGlobalError(null);
        const data = await api.listArtifacts(false);
        setArtifacts(data);

        // Select the first playable artifact
        const firstPlayable = data.find((a) => a.is_playable) || data[0];
        if (firstPlayable) {
          setActiveArtifact(firstPlayable);
        }
      } catch (err: any) {
        console.error('Failed to load artifacts:', err);
        setGlobalError(err.message || 'Unable to connect to the Origlyph backend.');
      }
    }
    loadInitialData();
  }, []);

  // Reset round state when active artifact changes
  const handleSelectArtifact = (id: string) => {
    const selected = artifacts.find((a) => a.id === id);
    if (selected) {
      setActiveArtifact(selected);
      setUserGuess(null);
      setUnlockedHints([]);
      setRevealData(null);
      setIsRevealModalOpen(false);
      setGraphData(null);
      setCurrentView('game');
    }
  };

  // Request progressive hint
  const handleUnlockHint = async (level: number) => {
    if (!activeArtifact) return;
    try {
      setIsLoadingHint(true);
      const hint = await api.getHint(activeArtifact.id, level);
      setUnlockedHints((prev) => [...prev, hint]);
    } catch (err: any) {
      console.error('Hint error:', err);
      alert(`Could not retrieve hint: ${err.message}`);
    } finally {
      setIsLoadingHint(false);
    }
  };

  // Submit geographic guess
  const handleSubmitGuess = async () => {
    if (!activeArtifact || !userGuess) return;
    try {
      setIsSubmitting(true);
      const res = await api.submitGuess(
        activeArtifact.id,
        userGuess.lat,
        userGuess.lng,
        unlockedHints.length
      );
      setRevealData(res);
      setIsRevealModalOpen(true);

      // Update session tally
      if (!completedIds.has(activeArtifact.id)) {
        setTotalScore((prev) => prev + res.final_score);
        setCompletedIds((prev) => new Set([...prev, activeArtifact.id]));
      }

      // Pre-load provenance graph for smooth transition
      api.getRelations(activeArtifact.id).then(setGraphData).catch(console.error);
    } catch (err: any) {
      console.error('Guess error:', err);
      alert(`Submission error: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Load and display provenance graph
  const handleOpenProvenance = async () => {
    if (!activeArtifact) return;
    try {
      setIsLoadingGraph(true);
      const relations = await api.getRelations(activeArtifact.id);
      setGraphData(relations);
      setIsRevealModalOpen(false);
      setCurrentView('global-graph');
    } catch (err: any) {
      console.error('Graph error:', err);
      alert(`Could not load provenance graph: ${err.message}`);
    } finally {
      setIsLoadingGraph(false);
    }
  };

  // Advance to next playable challenge
  const handleNextChallenge = () => {
    const playable = artifacts.filter((a) => a.is_playable);
    const currentIndex = playable.findIndex((a) => a.id === activeArtifact?.id);
    const nextIndex = (currentIndex + 1) % playable.length;
    handleSelectArtifact(playable[nextIndex].id);
  };

  const playableCount = artifacts.filter((a) => a.is_playable).length;

  return (
    <div className="app-container">
      <Header
        currentView={currentView}
        onNavigate={setCurrentView}
        onOpenIntegrationGuide={() => setIsGuideModalOpen(true)}
        totalScore={totalScore}
        completedCount={completedIds.size}
        playableCount={playableCount}
      />

      {globalError && (
        <div style={{ background: '#3b1812', color: '#ffc5bc', padding: '0.75rem 2rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.88rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <AlertCircle size={16} />
            {globalError} (Is the backend running on port 8000?)
          </div>
          <button
            onClick={() => window.location.reload()}
            style={{ background: 'transparent', border: '1px solid #ffc5bc', color: '#ffc5bc', padding: '0.2rem 0.6rem', borderRadius: '4px', cursor: 'pointer' }}
          >
            Retry
          </button>
        </div>
      )}

      {/* Main Challenge Game Layout */}
      {currentView === 'game' && activeArtifact && (
        <main className="game-layout">
          {/* Left Pane: Artifact & Hints */}
          <div className="artifact-pane">
            <ArtifactViewer artifact={activeArtifact} />

            <HintPanel
              unlockedHints={unlockedHints}
              onUnlockHint={handleUnlockHint}
              isLoading={isLoadingHint}
              disabled={!!revealData}
            />
          </div>

          {/* Right Pane: Interactive Cartographic Map */}
          <MapGuess
            userGuess={userGuess}
            onSelectCoordinates={setUserGuess}
            onSubmitGuess={handleSubmitGuess}
            revealData={revealData}
            isSubmitting={isSubmitting}
            disabled={!activeArtifact.is_playable}
          />
        </main>
      )}

      {/* Catalog View */}
      {currentView === 'catalog' && (
        <ArtifactCatalog
          artifacts={artifacts}
          activeArtifactId={activeArtifact?.id || ''}
          onSelectArtifact={handleSelectArtifact}
        />
      )}

      {/* Provenance Graph View */}
      {currentView === 'global-graph' && graphData && (
        <div style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto', width: '100%' }}>
          <ProvenanceGraph
            graphData={graphData}
            onSelectArtifact={handleSelectArtifact}
            onClose={() => setCurrentView('game')}
          />
        </div>
      )}

      {/* Reveal Modal */}
      {isRevealModalOpen && revealData && (
        <RevealModal
          reveal={revealData}
          onNextChallenge={handleNextChallenge}
          onOpenProvenance={handleOpenProvenance}
          onClose={() => setIsRevealModalOpen(false)}
        />
      )}

      {/* Integration Guide Modal */}
      {isGuideModalOpen && (
        <IntegrationGuideModal onClose={() => setIsGuideModalOpen(false)} />
      )}
    </div>
  );
};
