"""Main FastAPI entry point for Origlyph cultural heritage application."""
import logging
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from .config import settings
from .routes.health import router as health_router
from .routes.artifacts import router as artifacts_router
from .services.provenance import build_global_provenance_graph

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("origlyph")

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Decode the places behind culture. API for cultural heritage discovery and provenance.",
)

# Enable CORS for frontend clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS if settings.CORS_ORIGINS else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API Routers
app.include_router(health_router, prefix=settings.API_PREFIX)
app.include_router(artifacts_router, prefix=settings.API_PREFIX)


@app.get("/api/provenance/global")
def get_global_graph():
    """Return complete interconnected provenance network of all loaded artifacts."""
    return build_global_provenance_graph()


# Mount frontend static distribution if built (for unified single-process deployment)
FRONTEND_DIST = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
if FRONTEND_DIST.exists() and (FRONTEND_DIST / "index.html").exists():
    logger.info("Serving built frontend from %s", FRONTEND_DIST)
    app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIST / "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        # Don't intercept API routes
        if full_path.startswith("api"):
            return None
        file_path = FRONTEND_DIST / full_path
        if file_path.exists() and file_path.is_file():
            return FileResponse(file_path)
        return FileResponse(FRONTEND_DIST / "index.html")
