"""Health check and metadata routes."""
import os
from fastapi import APIRouter
from ..models.api import HealthResponse
from ..services.artifact_store import store

router = APIRouter(tags=["System"])


@router.get("/health", response_model=HealthResponse)
def get_health() -> HealthResponse:
    """Return backend health and catalog statistics."""
    playable = len(store.get_playable())
    total = len(store.get_all())
    env = os.getenv("ORIGLYPH_ENV", "development")
    return HealthResponse(
        status="ok",
        version="1.0.0",
        playable_artifacts=playable,
        total_artifacts=total,
        environment=env,
    )


@router.get("/manifest")
def get_manifest():
    """Return dataset source manifest and attribution records."""
    return store.get_manifest()
