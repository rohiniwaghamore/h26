"""Application settings and environment configuration."""
import os


class Settings:
    PROJECT_NAME: str = "Origlyph Cultural Heritage API"
    VERSION: str = "2.0.0"
    API_PREFIX: str = "/api"
    ENV: str = os.getenv("ORIGLYPH_ENV", "development")
    CORS_ORIGINS: list = [
        origin.strip()
        for origin in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000,http://127.0.0.1:5173").split(",")
        if origin.strip()
    ]


settings = Settings()
